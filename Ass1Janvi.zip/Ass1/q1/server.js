const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');
const querystring = require('querystring');

const PORT = 3000;

// Function to serve static files
const serveStaticFile = (res, filePath, contentType) => {
    fs.readFile(filePath, (error, content) => {
        if (error) {
            res.writeHead(500);
            res.end(`Sorry, there was an error: ${error.code} ..\n`);
        } else {
            res.writeHead(200, { 'Content-Type': contentType });
            res.end(content, 'utf-8');
        }
    });
};

// Create the server
const server = http.createServer((req, res) => {
    const parsedUrl = url.parse(req.url, true);

    // Handle GET request
    if (req.method === 'GET') {
        if (parsedUrl.pathname === '/') {
            serveStaticFile(res, path.join(__dirname, 'public', 'index.html'), 'text/html');
        } else if (parsedUrl.pathname === '/submit') {
            // Handle form submission here if needed
            res.writeHead(200, { 'Content-Type': 'text/plain' });
            res.end('Form submitted successfully!');
        } else {
            // Serve other static files
            const filePath = path.join(__dirname, 'public', parsedUrl.pathname);
            const extname = String(path.extname(filePath)).toLowerCase();
            const mimeTypes = {
                '.html': 'text/html',
                '.js': 'text/javascript',
                '.css': 'text/css',
                '.json': 'application/json',
                '.png': 'image/png',
                '.jpg': 'image/jpg',
                '.gif': 'image/gif',
                '.svg': 'image/svg+xml',
                '.wav': 'audio/wav',
                '.mp4': 'video/mp4',
                '.woff': 'application/font-woff',
                '.ttf': 'application/font-ttf',
                '.eot': 'application/vnd.ms-fontobject',
                '.otf': 'application/font-otf',
                '.txt': 'text/plain',
                '.xml': 'application/xml',
                '.pdf': 'application/pdf',
                '.zip': 'application/zip',
                '.css': 'text/css',
            };
            const contentType = mimeTypes[extname] || 'application/octet-stream';
            serveStaticFile(res, filePath, contentType);
        }
    }

    // Handle POST request
    else if (req.method === 'POST' && parsedUrl.pathname === '/submit') {
        let body = '';
        req.on('data', chunk => {
            body += chunk.toString(); // Convert Buffer to string
        });
        req.on('end', () => {
            const postData = querystring.parse(body);
            console.log('Received data:', postData.data);
            res.writeHead(200, { 'Content-Type': 'text/plain' });
            res.end('Data received: ' + postData.data);
        });
    } else {
        res.writeHead(404);
        res.end('404 Not Found');
    }
});

// Start the server
server.listen(PORT, () => {
    console.log(`Server is listening on http://localhost:${PORT}`);
});
