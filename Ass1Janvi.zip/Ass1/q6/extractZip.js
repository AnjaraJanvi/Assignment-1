// extractZip.js

const fs = require('fs');
const unzipper = require('unzipper');

function extractZip(zipFilePath, outputFolder) {
    fs.createReadStream(zipFilePath)
        .pipe(unzipper.Extract({ path: outputFolder }))
        .on('close', () => {
            console.log(`Extraction completed: ${outputFolder}`);
        })
        .on('error', (err) => {
            console.error(`Error during extraction: ${err.message}`);
        });
}

// Example usage
const zipFilePath = '../q5/output.zip'; // Adjust the path if needed
; // Change this to the path of your zip file
const outputFolder = 'extracted-files'; // Folder where extracted files will be saved

extractZip(zipFilePath, outputFolder);
