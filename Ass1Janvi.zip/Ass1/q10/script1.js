console.log('This is user-defined script 1.');
