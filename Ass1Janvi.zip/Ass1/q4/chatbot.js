// chatbot.js

class Chatbot {
    constructor(domain) {
        this.domain = domain;
        this.responses = {
            greeting: `Hello! I'm a chatbot specialized in ${this.domain}. How can I assist you today?`,
            farewell: `Goodbye! If you need any further assistance in ${this.domain}, feel free to ask!`,
            hours: `Our hours of operation are 9 AM to 5 PM, Monday to Friday.`,
            services: `We offer a variety of services including customer support, product inquiries, and technical assistance.`,
            faq: `You can ask me about our services, hours of operation, or any other questions you might have!`,
            default: `I'm sorry, I didn't understand that. Can you please rephrase your question?`
        };
    }

    respond(message) {
        const lowerMessage = message.toLowerCase();

        if (lowerMessage.includes('hello') || lowerMessage.includes('hi')) {
            return this.responses.greeting;
        } else if (lowerMessage.includes('bye') || lowerMessage.includes('goodbye')) {
            return this.responses.farewell;
        } else if (lowerMessage.includes('hours')) {
            return this.responses.hours;
        } else if (lowerMessage.includes('services') || lowerMessage.includes('what do you offer')) {
            return this.responses.services;
        } else if (lowerMessage.includes('faq') || lowerMessage.includes('questions')) {
            return this.responses.faq;
        } else {
            return this.responses.default;
        }
    }
}

module.exports = Chatbot;
